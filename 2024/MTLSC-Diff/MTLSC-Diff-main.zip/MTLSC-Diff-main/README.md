# MTLSC-Diff
This implementation of the paper "MTLSC-Diff: Multitask learning with diffusion models for hyperspectral image super-resolution and classification" (Knowledge-Based Systems 2024)

# Notes
    Please modify it according to your actual path. For example: data_path, load_path

# Usage
Environment:
    python 3.7
    torch                 1.13.1
    torchvision           0.14.1

# Training
    first:  python main_PC_SR.py
    second: python main_PC_classification.py

# Test:
    python main main_PC_guide_.py

# Cite
```
@article{QU2024112415,
title = {MTLSC-Diff: Multitask learning with diffusion models for hyperspectral image super-resolution and classification},
journal = {Knowledge-Based Systems},
volume = {303},
pages = {112415},
year = {2024},
issn = {0950-7051},
doi = {https://doi.org/10.1016/j.knosys.2024.112415},
url = {https://www.sciencedirect.com/science/article/pii/S0950705124010499},
author = {Jiahui Qu and Liusheng Xiao and Wenqian Dong and Yunsong Li}
}
```
