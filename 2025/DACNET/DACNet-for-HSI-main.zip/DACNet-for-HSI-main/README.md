DACNET

[Efficient Dynamic Attention 3D Convolution for Hyperspectral Image Classification](https://arxiv.org/abs/2503.23472)
