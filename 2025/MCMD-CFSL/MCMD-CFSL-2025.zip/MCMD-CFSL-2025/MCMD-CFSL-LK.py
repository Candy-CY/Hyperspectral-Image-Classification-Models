import copy

import numpy as np
import os
import argparse
import pickle
import time
import imp
import logging
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
import torch.nn.functional as F
import random
import torch
import torch.nn as nn
from torch.autograd import Variable
from torch.utils.tensorboard import SummaryWriter
# from sentence_transformers import SentenceTransformer

from model.mapping import Mapping
from model.encoder5 import Encoder

from utils.dataloader import get_HBKC_data_loader, Task, get_target_dataset, getMetaTrainLabeledDataset, get_metatrain_Labeled_data_loader
from utils import utils, encode_class_label, loss_function

from practice import t_sne


parser = argparse.ArgumentParser(description="Few Shot Visual Recognition")
parser.add_argument('--config', type=str, default=os.path.join( './config', 'longkou9.py'))
args = parser.parse_args()

# 加载超参数
config = imp.load_source("", args.config).config # (name, pathname)
train_opt = config['train_config'] # 得到train_opt对象

data_path = config['data_path']
save_path = config['save_path']
source_data = config['source_data']
target_data = config['target_data']
target_data_gt = config['target_data_gt']
log_dir = config['log_dir']
patch_size = train_opt['patch_size']
batch_task = train_opt['batch_task']
emb_size = train_opt['d_emb']
SRC_INPUT_DIMENSION = train_opt['src_input_dim']
TAR_INPUT_DIMENSION = train_opt['tar_input_dim']
N_DIMENSION = train_opt['n_dim']
SRC_CLASS_NUM = train_opt['src_class_num']
SHOT_NUM_PER_CLASS = train_opt['shot_num_per_class']
QUERY_NUM_PER_CLASS = train_opt['query_num_per_class']
EPISODE = 5000
COARSE_EP = train_opt['coarse_ep']
FINE_EP = train_opt['fine_ep']
LEARNING_RATE = train_opt['lr']
lambda_1 = train_opt['lambda_1']
GPU = 1
TAR_CLASS_NUM = train_opt['tar_class_num'] # the number of class
TAR_LSAMPLE_NUM_PER_CLASS = train_opt['tar_lsample_num_per_class'] # the number of labeled samples per class
# hid_units = train_opt['hid_units']
HIDDEN_CHANNELS = train_opt['hidden_channels']
WEIGHT_DECAY = train_opt['weight_decay']
RS=SRC_INPUT_DIMENSION//16-1
RT=TAR_INPUT_DIMENSION//16-1
utils.same_seeds(0)


source_spa_text=[
  "Surfaces often exhibit a reflective and relatively uniform texture, with subtle variations due to ripples or waves.",
  "Might show a compact and evenly distributed texture, possibly with footprint patterns.",
  "May have an uneven texture due to recreational activities and natural soil structure.",
  "Could display a rough and clumpy texture, reflecting the agricultural use and tillage.",
  "Can have a diverse range of textures, from fine grasses to denser shrubs, with variable patterns.",
  "May appear as scattered and random textures within the cultivated areas.",
  "Typically show complex textures due to the mix of tree canopies and understory vegetation.",
  "Usually have a fine and even texture, with subtle variations in height and density.",
  "May display a uniform and grid-like texture, indicative of cultivated rows.",
  "Might exhibit a lighter and less dense texture, as the crops are just beginning to grow.",
  "Can present a structured and repeated texture pattern, following the lines of planting.",
  "Often show a distinct smooth and artificial texture.",
  "May have a varied texture depending on the material and surface characteristics.",
  "Can exhibit a more uniform and darker texture.",
  "Likely show a consistent and smooth texture.",
  "May have a distinct and uniform texture, possibly including certain types of roofing or decorative elements.",
  "Such as sports fields, may have a very even and well-maintained texture, with clear delineations between areas.",
  "Common in roads and parking lots, have a hard and uniform texture with clear, sharp edges."
]
target_spa_text=["Corn plants stand upright, forming a regular inter-row structure, with long and broad leaves that exhibit a distinct vertical texture. In high-resolution images, the stalks and leaf details of the plants can be clearly seen.",
"Cotton plants are relatively short with smaller leaves, forming a dense shrub-like structure. After flowering and boll formation, the spatial texture becomes more complex, possibly with enhanced reflection from white cotton fluff.",
"Sesame plants stand upright with variable heights, and smaller leaves that form a slender vertical texture. As they mature, the upper part of the plant may have clusters of seed pods, increasing spatial heterogeneity.",
"The plants are relatively short with large and round leaves, forming a dense horizontal texture. In high-resolution images, the overlapping of leaves and the supporting structure of the stalks can be observed.",
"The plant structure is similar to that of broadleaf soybeans, but with narrower leaves, forming a finer texture. The narrow leaves may leave more gaps between rows, affecting the overall spatial uniformity.",
"Rice plants stand upright with slender leaves, forming a dense vertical texture. In paddy fields, the plants are surrounded by water, creating a unique spatial characteristic.",
"The water surface is smooth, with reflectivity influenced by wind force and angle of sunlight, forming a texture that is either sleek or rippled.",
"Roads form straight or curved textures, while houses form regular or irregular geometric shapes; together they constitute the structure of urban or rural areas.",
"The variety and growth conditions of weeds lead to a diversity in spatial texture, ranging from sparse to dense, and from low to tall, forming irregular and complex textures. In high-resolution images, the morphological characteristics of different weed species can be discerned."]
source_spe_text=["exhibit high reflectance in the near-infrared (NIR) band and lower reflectance in the shortwave infrared (SWIR) band.",
  "The spectral reflectance of bare soil in schools may be higher in the near-infrared region because compacted soil reflects more near-infrared light.",
  "The spectrum of bare soil in parks may exhibit more vegetation characteristics, such as chlorophyll absorption bands, especially in the red and near-infrared regions.",
  "The spectrum of bare soil in farmland may show clear changes in soil moisture and organic matter content, which are manifested in the spectrum as specific absorption features and changes in reflectance.",
  "shows high reflectance in the NIR band ",
  "shows high reflectance in the NIR band but may differ in reflectance due to different growth stages and density.",
  " exhibit high reflectance, especially in the NIR band",
  "show high reflectance in the NIR band and a significant drop in reflectance in the red edge region.",
  "show high reflectance in the NIR band and a significant drop in reflectance in the red edge region. but may differ slightly due to specific growth stages of the rice crop.",
  "Early growth stage rice fields may spectrally differ from mature stages, especially in vegetation indices.",
  "Row crops like corn or beans may spectrally differ from forests or grasslands, especially at different growth stages.",
  "Plastic greenhouses may exhibit low reflectance due to the material's absorption rather than reflection of light.",
  "Non-dark man-made objects like buildings may show moderate reflectance, depending on the material and surface characteristics.",
  "Dark man-made objects like asphalt or dark roofs typically show low reflectance in the NIR band.",
  "Blue man-made objects like swimming pools may have higher reflectance in the blue band.",
  "Red man-made objects may have higher reflectance in the red band.",
  "MArtificial grass, such as for decorative or sports fields, may spectrally resemble natural grass but differ due to the material used.",
  "Asphalt surfaces typically show low reflectance, especially in the NIR band."]
target_spe_text = ["In the visible light region, especially in the green band, reflectance is relatively low, indicating chlorophyll absorption. In the near-infrared region (NIR), reflectance significantly increases, forming a typical reflectance peak of vegetation. In the shortwave infrared (SWIR) region, reflectance is low, reflecting the moisture content of plants.",
"Reflectance is low in the visible light region, high in the NIR region, and low in the SWIR region. Cotton in the mature stage may have higher reflectance in the visible light region due to the presence of fibers.",
"Reflectance is low in the visible light region, high in the NIR region, and low in the SWIR region. Mature sesame plants may exhibit a slight increase in reflectance in the SWIR region, reflecting the drying of seed pods.",
"Reflectance is low in the visible light region, high in the NIR region, and low in the SWIR region. Broadleaf soybeans with larger leaves may result in higher reflectance in the NIR region compared to narrow-leaf varieties.",
"Similar to broadleaf soybeans, but reflectance in the NIR region may be slightly lower, reflecting differences in leaf shape.",
"Reflectance is low in the visible light region, high in the NIR region, and low in the SWIR region. Rice growing in an aquatic environment may have spectral characteristics affected by water surface reflections.",
"Reflectance is low in the visible light region, particularly in the blue-green bands. Reflectance in the NIR and SWIR regions is extremely low, unless there are suspended solids or algae in the water.",
"Roads have moderate to high reflectance in the visible light region, depending on the material (such as asphalt or concrete). Roofing materials of houses (such as tiles, metal, or asbestos cement) vary in reflectance in the visible light region, with lower reflectance in the SWIR region.",
"The spectral characteristics of mixed weeds vary by species, but overall, reflectance is low in the visible light region, high in the NIR region, and low in the SWIR region. A mixture of different weeds may lead to inconsistencies in spectral characteristics."]

from transformers import BertModel, BertTokenizer
model = BertModel.from_pretrained('bert-base-uncased') # base 768 large 768
model.eval()
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')


w1 = tokenizer(source_spa_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_w1 = model(**w1)
outputs_w1_src = outputs_w1.last_hidden_state[:, 0, :]  # (num_classess, 768)

w2 = tokenizer(target_spa_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_w2 = model(**w2)
outputs_w2_tar = outputs_w2.last_hidden_state[:, 0, :]  # (num_classess, 768)

g1 = tokenizer(source_spe_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_g1 = model(**g1)
outputs_g1_src = outputs_g1.last_hidden_state[:, 0, :]  # (num_classess, 768)

g2 = tokenizer(target_spe_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_g2 = model(**g2)
outputs_g2_tar = outputs_g2.last_hidden_state[:, 0, :]  # (num_classess, 768)



outputs_w1_src =outputs_w1_src.cpu().numpy()
outputs_w2_src =outputs_w2_tar.cpu().numpy()
outputs_g1_src =outputs_g1_src.cpu().numpy()
outputs_g2_src =outputs_g2_tar.cpu().numpy()


# 加载源域数据
with open(os.path.join(data_path, source_data), 'rb') as handle: # rb指的是二进制只读
    source_imdb = pickle.load(handle) # pickle.load() 将类文件对象转化为对象，可以看作文件转化为对象，反序列化过程。

data_train = source_imdb['data'] # (77592, 9, 9, 128)
labels_train = source_imdb['Labels'] # (77592, )

# 获取源域CH全部19个类的数据字典train_dict
keys_all_train = sorted(list(set(labels_train)))  # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
label_encoder_train = {}
for i in range(len(keys_all_train)):
    label_encoder_train[keys_all_train[i]] = i  # {0:0, 1:1,...,...}
train_dict = {}
for class_, path in zip(labels_train, data_train):
    if label_encoder_train[class_] not in train_dict:
        train_dict[label_encoder_train[class_]] = []
    train_dict[label_encoder_train[class_]].append(path) # 按类别划分源域数据 {5:[[data5],[data6]],1:[data0],[data1]}
del keys_all_train
del label_encoder_train

# 获取源域CH用于元训练的18个类的数据字典。CH共19个类，将以前的数据集少于200个样本的类别过滤掉，剩下18个类别，每类200个标记样本
metatrain_data = utils.sanity_check(train_dict) # dict:18 list:200 (9,9,128)


for class_ in metatrain_data: # 200 * 18 = 3600
    for i in range(len(metatrain_data[class_])):
        metatrain_data[class_][i] = np.transpose(metatrain_data[class_][i], (2, 0, 1)) # (9,9,128) -> (128,9,9)

# 加载目标域数据
test_data = os.path.join(data_path,target_data)
test_label = os.path.join(data_path,target_data_gt)
Data_Band_Scaler, GroundTruth = utils.load_data(test_data, test_label)

# 损失初始化
crossEntropy = nn.CrossEntropyLoss().to(GPU)
cos_criterion = nn.CosineSimilarity(dim=1).to(GPU)

infoNCE_Loss = loss_function.ContrastiveLoss(batch_size = TAR_CLASS_NUM,device=0).to(GPU)

# 实验结果指标
nDataSet = 10
acc = np.zeros([nDataSet, 1]) # 每轮的准确率
A = np.zeros([nDataSet, TAR_CLASS_NUM]) # 每轮每类的准确率
k = np.zeros([nDataSet, 1]) # Kappa
best_predict_all = [] # 最好的预测结果，存什么
best_G, best_RandPerm, best_Row, best_Column, best_nTrain = None,None,None,None,None


seeds =[1336,1227,1228,0000,2728,7575,9191,1718,8181,9999]

def preprocess_data(query_set, query_labels):
    """
    预处理数据，按类别分组。

    """
    data_by_class = {i: [] for i in range(TAR_CLASS_NUM)}
    for idx, label in enumerate(query_labels):
        data_by_class[label.item()].append(idx)

    return data_by_class
def split_tensor(input_tensor):
    N, C, H, W = input_tensor.shape
    if H != 9 or W != 9:
        raise ValueError("Each patch must be of size (9, 9).")

    # 提取四个角落的子patch
    patches_per_image =torch.cat([
        input_tensor[:, :, :5, :5],   # 左上
        input_tensor[:, :, :5, 4:],   # 右上
        input_tensor[:, :, 4:, :5],   # 左下
        input_tensor[:, :, 4:, 4:]     # 右下
    ], dim=1)
    output_tensor = patches_per_image.view(N * 4, C, 5, 5)# 右下

    return output_tensor

def split_tensor2(input_tensor,c_num):
    N, C, H, W = input_tensor.shape
    if H != 9 or W != 9:
        raise ValueError("Each patch must be of size (9, 9).")

    n_k=c_num//16-1
    # 沿通道维度切分 input_tensor
    patches_per_channel = torch.cat([
        input_tensor[:, i * 16:(i + 2) * 16, :, :]
        for i in range(n_k)
    ],dim=1)

    output_tensor = patches_per_channel.view(N * n_k, 32, 9, 9)

    return output_tensor




def soft_cross_entropy(input, target, reduction='sum'):
    # input 是学生网络的logits
    # target 是教师网络的软标签概率分布
    log_prob = F.log_softmax(input, dim=1)
    loss = -torch.mean(target * log_prob, dim=1)

    if reduction == 'mean':
        return torch.mean(loss)
    elif reduction == 'sum':
        return torch.sum(loss)
    else:
        return loss
def soft_cross_entropy2(input, target, reduction='sum'):
    # input 是学生网络的logits
    # target 是教师网络的软标签概率分布
    log_prob = F.log_softmax(input, dim=-1)
    loss = -torch.mean(target * log_prob, dim=-1)

    if reduction == 'mean':
        return torch.mean(loss)
    elif reduction == 'sum':
        return torch.sum(loss)
    else:
        return loss

def local_global_distillation_loss_flattened(global_preds, local_preds, R):

    assert global_preds.dim() == 2 and local_preds.dim() == 2, "输入张量维度不符合要求"
    N, C = global_preds.shape
    assert (R * N) == local_preds.shape[0] and C == local_preds.shape[1], "输入张量大小不匹配"


    global_preds_repeated = global_preds.repeat_interleave(R, dim=0)

    l = local_preds
    g = global_preds_repeated
    max_l = l.max(dim=-1, keepdim=True)[0]
    max_g = g.max(dim=-1, keepdim=True)[0]
    min_l = l.min(dim=-1, keepdim=True)[0]
    min_g = g.min(dim=-1, keepdim=True)[0]
    probabilities1 = (l - min_l) * 1.0 / (max_l - min_l)
    probabilities2 = (g - min_g) * 1.0 / (max_g - min_g)

    _, target_labels = torch.max(global_preds_repeated, dim=1)


    cross_entropy_loss = soft_cross_entropy(probabilities1, probabilities2)

    loss_sum = cross_entropy_loss.sum()

    L_self = loss_sum / (R * N)

    return L_self



def cross_image_local_global_distillation_loss_flattened2(query_labels, global_preds, local_preds_flattened,
                                                         data_by_class, R):

    N, C = global_preds.shape
    total_predictions = R * N
    assert local_preds_flattened.shape == (total_predictions, C), "输入张量大小不匹配"

    loss_sum = 0.0

    query_index = []
    for i in range(N):
        # 获取当前图像的类别

     current_label = query_labels[i]
        # 从当前类别中随机选择一个不同的索引
     other_indices = data_by_class[current_label.item()]
     for indices in other_indices:
         query_index.append(indices)

    local_indices = [R * q + r for q in query_index for r in range(R)]
    p1_tensors = local_preds_flattened[local_indices]
    p2_tensors = global_preds[[i for i in range(N)]].repeat_interleave(R*19, dim=0)
    l = p1_tensors
    g = p2_tensors
    max_l = l.max(dim=-1, keepdim=True)[0]
    max_g = g.max(dim=-1, keepdim=True)[0]
    min_l = l.min(dim=-1, keepdim=True)[0]
    min_g = g.min(dim=-1, keepdim=True)[0]
    probabilities1 = (l - min_l) * 1.0 / (max_l - min_l)
    probabilities2 = (g - min_g) * 1.0 / (max_g - min_g)

    cross_entropy_loss = soft_cross_entropy2(probabilities1, probabilities2)

    loss_sum += cross_entropy_loss

    # 平均所有样本的损失
    L_cross = loss_sum / (N * R*19)

    return L_cross


def hinge(input, margin=0.2):
    return torch.clamp(input, min=margin)
# 日志设置
def entropy(p):
    p = F.softmax(p, dim=1)
    return -torch.mean(torch.sum(p * torch.log(p + 1e-5), 1))

# 日志设置
for i in range(1):
 TAR_LSAMPLE_NUM_PER_CLASS=i+5
 experimentSetting = '{}way_{}shot_{}'.format(TAR_CLASS_NUM, TAR_LSAMPLE_NUM_PER_CLASS, target_data.split('/')[0])
 for handler in logging.root.handlers[:]:
     logging.root.removeHandler(handler)
 utils.set_logging_config(os.path.join(log_dir, experimentSetting), nDataSet)  # ./logs/9way_5shot_UP/
# 日志初始化
 logger = logging.getLogger('main')
 logger.info('seeds_list:{}'.format(seeds))
 out_channel = 128
 Temp = 0.05
 temp = 0.05

 tensor_index = torch.arange(100)
 ii=0
 acc = np.zeros([nDataSet, 1])  # 每轮的准确率
 A = np.zeros([nDataSet, TAR_CLASS_NUM])  # 每轮每类的准确率
 k = np.zeros([nDataSet, 1])  # Kappa
 best_predict_all = []  # 最好的预测结果，存什么
 best_G, best_RandPerm, best_Row, best_Column, best_nTrain = None, None, None, None, None
for iDataSet in range(nDataSet) :
    logger.info('emb_size:{}'.format(emb_size))
    logger.info('num_generation:{}'.format(config['num_generation']))
    logger.info('patch_size:{}'.format(patch_size))
    logger.info('seeds:{}'.format(seeds[iDataSet]))



    utils.same_seeds(seeds[iDataSet])


    train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column,nTrain,test_loader2  = get_target_dataset(Data_Band_Scaler=Data_Band_Scaler,
                                                                                                              GroundTruth=GroundTruth,
                                                                                                              class_num=TAR_CLASS_NUM,
                                                                                                              tar_lsample_num_per_class=TAR_LSAMPLE_NUM_PER_CLASS,
                                                                                                              shot_num_per_class=TAR_LSAMPLE_NUM_PER_CLASS,
                                                                                                              patch_size=patch_size,test2=True)
    num_supports, num_samples, query_edge_mask, evaluation_mask = utils.preprocess(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS, batch_task, GPU)


    mapping_src = Mapping(SRC_INPUT_DIMENSION, N_DIMENSION).to(GPU)
    mapping_tar = Mapping(TAR_INPUT_DIMENSION, N_DIMENSION).to(GPU)
    mapping_tar_kuai = Mapping(32, N_DIMENSION).to(GPU)
    mapping_src_kuai = Mapping(32, N_DIMENSION).to(GPU)
    encoder = Encoder(n_dimension=N_DIMENSION, patch_size=patch_size, emb_size=emb_size).to(GPU)


    mapping_src_optim = torch.optim.SGD(mapping_src.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=WEIGHT_DECAY)
    mapping_tar_optim = torch.optim.SGD(mapping_tar.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=WEIGHT_DECAY)
    encoder_optim = torch.optim.SGD(encoder.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=WEIGHT_DECAY)
    mapping_tar_optim_kuai = torch.optim.SGD(mapping_tar_kuai.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                             weight_decay=WEIGHT_DECAY)
    mapping_src_optim_kuai = torch.optim.SGD(mapping_src_kuai.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                             weight_decay=WEIGHT_DECAY)

    mapping_src.apply(utils.weights_init)
    mapping_tar.apply(utils.weights_init)
    encoder.apply(utils.weights_init)
    mapping_tar_kuai.apply(utils.weights_init)
    mapping_src_kuai.apply(utils.weights_init)

    mapping_src.to(GPU)
    mapping_tar.to(GPU)
    encoder.to(GPU)
    Siamese_model = copy.deepcopy(encoder).to(GPU)
    mapping_tar_kuai.to(GPU)
    mapping_src_kuai.to(GPU)
    # 训练模式
    mapping_src.train()
    mapping_tar.train()
    mapping_tar_kuai.train()
    mapping_src_kuai.train()
    encoder.train()
    logger.info("Training...")
    last_accuracy = 0.0
    best_episode = 0
    total_hit_src, total_num_src, total_hit_tar, total_num_tar, acc_src, acc_tar = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0


    train_start = time.time()
    writer = SummaryWriter()

    # source_iter = iter(source_data_loader)
    ssl_iter = iter(test_loader2)
    data_embed_collect = []
    best_data_embed_collect = []
    for episode in range(EPISODE) :
        # print("episode = ", episode)
        # Source and Target Few-Shot
        task_src = Task(metatrain_data, TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_src = get_HBKC_data_loader(task_src, num_per_class=SHOT_NUM_PER_CLASS, split="train", shuffle=False)
        query_dataloader_src = get_HBKC_data_loader(task_src, num_per_class=QUERY_NUM_PER_CLASS, split="test", shuffle=False)

        task_tar = Task(target_da_metatrain_data, TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_tar = get_HBKC_data_loader(task_tar, num_per_class=SHOT_NUM_PER_CLASS, split="train", shuffle=False)
        query_dataloader_tar = get_HBKC_data_loader(task_tar, num_per_class=QUERY_NUM_PER_CLASS, split="test", shuffle=False)

        support_src, support_label_src = next(support_dataloader_src.__iter__())  # [9, 128, 9, 9]
        query_src, query_label_src = next(query_dataloader_src.__iter__())  # (171, 128, 9, 9)
        # list
        support_real_labels_src = task_src.support_real_labels
        support_real_labels_tar = task_tar.support_real_labels



        w1_support_src = torch.zeros(TAR_CLASS_NUM, 768)  # (9, 768)
        for i, class_id in enumerate(support_real_labels_src):
            w1_support_src[i] = torch.from_numpy(outputs_w1_src[class_id])

        # check float loss = only 4
        w2_support_tar = torch.zeros(TAR_CLASS_NUM, 768)  # (9, 768)
        for i, class_id in enumerate(support_real_labels_tar):
            w2_support_tar[i] = torch.from_numpy(outputs_w2_src[class_id])

        g1_support_src = torch.zeros(TAR_CLASS_NUM, 768)  # (9, 768)
        for i, class_id in enumerate(support_real_labels_src):
            g1_support_src[i] = torch.from_numpy(outputs_g1_src[class_id])

        g2_support_tar = torch.zeros(TAR_CLASS_NUM, 768)  # (9, 768)
        for i, class_id in enumerate(support_real_labels_tar):
            g2_support_tar[i] = torch.from_numpy(outputs_g2_src[class_id])

        support_tar, support_label_tar = next(support_dataloader_tar.__iter__())  # [9, 128, 9, 9]
        query_tar, query_label_tar = next(query_dataloader_tar.__iter__())  # (171, 128, 9, 9)
        q_new_s = split_tensor(query_src)
        q_data_s = preprocess_data(query_src, query_label_src)
        q_new_s_k = split_tensor2(query_src, SRC_INPUT_DIMENSION)
        q_new_t = split_tensor(query_tar)
        q_data_t = preprocess_data(query_tar, query_label_tar)
        q_new_t_k = split_tensor2(query_tar, TAR_INPUT_DIMENSION)
        support_features_src, spatial_feature_src, spectral_feature_src, semantic_feature_src, semantic_feature2_src = encoder(
            mapping_src(support_src.to(GPU)), semantic_feature=w1_support_src.to(GPU),
            semantic_feature2=g1_support_src.to(GPU), s_or_q="support")  # (9, 160)
        query_features_src,spa_st,spe_st = encoder(mapping_src(query_src.to(GPU)),f=True)  # (171, 160)

        support_features_tar, spatial_feature_tar, spectral_feature_tar, semantic_feature_tar, semantic_feature2_tar = encoder(
            mapping_tar(support_tar.to(GPU)), semantic_feature=w2_support_tar.to(GPU),
            semantic_feature2=g2_support_tar.to(GPU), s_or_q="support")  # (9, 160)
        query_features_tar,spa_qt,spe_qt = encoder(mapping_tar(query_tar.to(GPU)),f=True)  # (171, 160)
        map_k = mapping_tar_kuai(q_new_t_k.to(GPU))
        map_k_s=    mapping_src_kuai(q_new_s_k.to(GPU))
        with torch.no_grad():
            querys_new_features_s ,spa_s,spe_s= Siamese_model(mapping_src(q_new_s.to(GPU)), z=True,f=True)
            querys_new_features_t,spa_t,spe_t = Siamese_model(mapping_tar(q_new_t.to(GPU)), z=True,f=True)
            querys_new_features_t_k ,spa_k,spe_k= Siamese_model(map_k,f=True)
            querys_new_features_s_k, spa_k_s, spe_k_s = Siamese_model(map_k_s, f=True)
        # Prototype
        if SHOT_NUM_PER_CLASS > 1:
            support_proto_src = support_features_src.reshape(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1)  # (9, 160)
            support_proto_tar = support_features_tar.reshape(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1)  # (9, 160)

        else:
            support_proto_src = support_features_src
            support_proto_tar = support_features_tar


        logits_src = utils.euclidean_metric(query_features_src, support_proto_src)
        f_loss_src = crossEntropy(logits_src, query_label_src.long().to(GPU))
        logits_new_t = utils.euclidean_metric(querys_new_features_t, support_features_tar)
        logits_new_k = utils.euclidean_metric(querys_new_features_t_k, support_features_tar)

        logits_new_s = utils.euclidean_metric(querys_new_features_s, support_features_src)
        logits_new_k_s = utils.euclidean_metric(querys_new_features_s_k, support_features_src)

        logits_src_spa = utils.euclidean_metric(spa_st, spatial_feature_src)
        logits_src_spe = utils.euclidean_metric(spe_st, spectral_feature_src)

        logits_tar_spa = utils.euclidean_metric(spa_qt, spatial_feature_tar)
        logits_tar_spe = utils.euclidean_metric(spe_qt, spectral_feature_tar)



        logits_tar = utils.euclidean_metric(query_features_tar, support_proto_tar)
        f_loss_tar = crossEntropy(logits_tar, query_label_tar.long().to(GPU))

        f_loss = f_loss_src + f_loss_tar

        z_loss1_s = local_global_distillation_loss_flattened(logits_src, logits_new_s, 4)
        z_loss2_s = cross_image_local_global_distillation_loss_flattened2(query_label_src, logits_src, logits_new_s,
                                                                          q_data_s, 4)
        z_loss_s = z_loss1_s + 0.15 * z_loss2_s


        z_loss1_s_k = local_global_distillation_loss_flattened(logits_src, logits_new_k_s, RS)
        z_loss2_s_k= cross_image_local_global_distillation_loss_flattened2(query_label_src, logits_src, logits_new_k_s,
                                                                          q_data_s, RS)
        z_loss_s_k= z_loss1_s_k + 0.15 * z_loss2_s_k




        z_loss1_t = local_global_distillation_loss_flattened(logits_tar, logits_new_t, 4)
        z_loss2_t = cross_image_local_global_distillation_loss_flattened2(query_label_tar, logits_tar, logits_new_t,
                                                                          q_data_t, 4)

        z_loss_t = z_loss1_t + 0.15 * z_loss2_t


        z_loss1_t_k = local_global_distillation_loss_flattened(logits_tar, logits_new_k, RT)
        z_loss2_t_k= cross_image_local_global_distillation_loss_flattened2(query_label_tar, logits_tar, logits_new_k,
                                                                          q_data_t, RT)

        z_loss_t_k= z_loss1_t_k + 0.15 * z_loss2_t_k



        text_align_loss_src = infoNCE_Loss(spatial_feature_src, semantic_feature_src) + infoNCE_Loss(
            spectral_feature_src, semantic_feature2_src)
        text_align_loss_tar = infoNCE_Loss(spatial_feature_tar, semantic_feature_tar) + infoNCE_Loss(
            spectral_feature_tar, semantic_feature2_tar)

        loss = f_loss + z_loss_t_k + z_loss_t + z_loss_s_k + z_loss_s+0.1*(text_align_loss_tar+text_align_loss_src)

        # Update parameters
        mapping_src.zero_grad()
        mapping_tar.zero_grad()
        encoder.zero_grad()

        loss.backward()

        mapping_src_optim.step()
        mapping_tar_optim.step()
        encoder_optim.step()
        for param_q, param_k in zip(encoder.parameters(), Siamese_model.parameters()):
            param_k.data = param_k.data * 0.90 + param_q.data * (1. - 0.90)

        total_hit_src += torch.sum(torch.argmax(logits_src, dim=1).cpu() == query_label_src).item()
        total_num_src += query_src.shape[0]
        acc_src = total_hit_src / total_num_src

        total_hit_tar += torch.sum(torch.argmax(logits_tar, dim=1).cpu() == query_label_tar).item()
        total_num_tar += query_tar.shape[0]
        acc_tar = total_hit_tar / total_num_tar

        if (episode + 1) % 100 == 0:
            # tensor.item() 把张量转换为python标准数字返回，仅适用只有一个元素的张量。
            logger.info('episode: {:>3d}, f_loss: {:6.4f}, loss: {:6.4f}, acc_src: {:6.4f}, acc_tar: {:6.4f}'.format(
                episode + 1,
                f_loss.item(),
                loss.item(),
                acc_src,
                acc_tar))


            writer.add_scalar('Loss/f_loss', f_loss.item(), episode + 1)

            writer.add_scalar('Loss/loss', loss.item(), episode + 1)

            writer.add_scalar('Acc/acc_src', acc_src, episode + 1)
            writer.add_scalar('Acc/acc_tar', acc_tar, episode + 1)


        if (episode + 1) % 500 == 0 or episode == 0:
            with torch.no_grad():
                # test
                logger.info("Testing ...")
                train_end = time.time()
                mapping_tar.eval()
                encoder.eval()
                total_rewards = 0
                counter = 0
                accuracies = []
                predict = np.array([], dtype=np.int64)
                predict_gnn = np.array([], dtype=np.int64)
                labels = np.array([], dtype=np.int64)

                train_datas, train_labels,index = next(train_loader.__iter__())

                support_real_labels = train_labels

                semantic_support = torch.zeros(TAR_CLASS_NUM*TAR_LSAMPLE_NUM_PER_CLASS, 768)  # (9*5=45, 768)


                train_features = encoder(mapping_tar(Variable(train_datas.float()).to(GPU)))
                train_features2=train_features
                max_value = train_features.max()
                min_value = train_features.min()
                print(max_value.item())
                print(min_value.item())
                train_features = (train_features - min_value) * 1.0 / (max_value - min_value)

                KNN_classifier = KNeighborsClassifier(n_neighbors=1)
                KNN_classifier.fit(train_features.cpu().detach().numpy(), train_labels)
                data_embed_collect.append(train_features)
                for test_datas, test_labels,train_index in test_loader:
                    batch_size = test_labels.shape[0]

                    test_features = encoder(mapping_tar((Variable(test_datas.float()).to(GPU))))
                    test_features = (test_features - min_value) * 1.0 / (max_value - min_value)
                    predict_labels = KNN_classifier.predict(test_features.cpu().detach().numpy())
                    test_labels = test_labels.numpy()
                    rewards = [1 if predict_labels[j] == test_labels[j] else 0 for j in range(batch_size)]

                    total_rewards += np.sum(rewards)
                    counter += batch_size

                    predict = np.append(predict, predict_labels)
                    labels = np.append(labels, test_labels)

                    accuracy = total_rewards / 1.0 / counter
                    accuracies.append(accuracy)

                test_accuracy = 100. * total_rewards / len(test_loader.dataset)
                writer.add_scalar('Acc/acc_test', test_accuracy, episode + 1)

                logger.info('\t\tAccuracy: {}/{} ({:.2f}%)\n'.format(total_rewards, len(test_loader.dataset), 100. * total_rewards / len(test_loader.dataset)))
                test_end = time.time()

                # Training mode
                mapping_tar.train()
                encoder.train()
                if test_accuracy > last_accuracy:
                    last_accuracy = test_accuracy
                    best_episode = episode
                    acc[iDataSet] = 100. * total_rewards / len(test_loader.dataset)
                    OA = acc
                    C = metrics.confusion_matrix(labels, predict)
                    A[iDataSet, :] = np.diag(C) / np.sum(C, 1, dtype=float)
                    best_predict_all = predict
                    best_G, best_RandPerm, best_Row, best_Column, best_nTrain = G, RandPerm, Row, Column, nTrain
                    k[iDataSet] = metrics.cohen_kappa_score(labels, predict)
                    best_data_embed_collect = data_embed_collect
                data_embed_collect = []
                logger.info('best episode:[{}], best accuracy={}'.format(best_episode + 1, last_accuracy))

    logger.info('iter:{} best episode:[{}], best accuracy={}'.format(iDataSet, best_episode + 1, last_accuracy))
    logger.info ("train time per DataSet(s): " + "{:.5f}".format(train_end-train_start))
    logger.info("accuracy list: {}".format(acc))
    logger.info('***********************************************************************************')
    for i in range(len(best_predict_all)):
        best_G[best_Row[best_RandPerm[best_nTrain + i]]][best_Column[best_RandPerm[best_nTrain + i]]] = best_predict_all[i] + 1

OAMean = np.mean(acc)
OAStd = np.std(acc)

AA = np.mean(A, 1)
AAMean = np.mean(AA,0)
AAStd = np.std(AA)

kMean = np.mean(k)
kStd = np.std(k)

AMean = np.mean(A, 0)
AStd = np.std(A, 0)

logger.info ("train time per DataSet(s): " + "{:.5f}".format(train_end-train_start)) # 这个不是平均时间！是最后一个种子的时间！
logger.info ("test time per DataSet(s): " + "{:.5f}".format(test_end-train_end)) # 这个不是平均时间！是最后一个种子的时间！
logger.info ("average OA: " + "{:.2f}".format(OAMean) + " +- " + "{:.2f}".format( OAStd))
logger.info ("average AA: " + "{:.2f}".format(100 * AAMean) + " +- " + "{:.2f}".format(100 * AAStd))
logger.info ("average kappa: " + "{:.4f}".format(100 *kMean) + " +- " + "{:.4f}".format(100 *kStd))
logger.info ("accuracy list: {}".format(acc))
logger.info ("accuracy for each class: ")
for i in range(TAR_CLASS_NUM):
    logger.info ("Class " + str(i) + ": " + "{:.2f}".format(100 * AMean[i]) + " +- " + "{:.2f}".format(100 * AStd[i]))
