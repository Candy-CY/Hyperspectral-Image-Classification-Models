import torch
import torch.nn as nn
import torch.nn.functional
import einops
import torch
import torch.nn.functional as F
from torch import nn
from einops import rearrange, repeat


class DWConv1D(nn.Module):
    def __init__(self, dim=768):
        super(DWConv1D, self).__init__()
        # 定义一个一维深度卷积层，输入和输出通道数相同，卷积核大小为3，步幅为1，填充为1，组数为输入通道数
        self.dwconv = nn.Conv1d(dim, dim, kernel_size=3, stride=1, padding=1, bias=True, groups=dim)

    def forward(self, x):
        # 调整形状为 (B, C, N)     (batch_size, sequence_length, num_channels)
        x = x.transpose(1, 2).contiguous()
        x = self.dwconv(x)  # 进行深度卷积操作
        # 调整形状为 (B, N, C)
        x = x.transpose(1, 2).contiguous()
        return x


class ConvolutionalGLU_1d(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        hidden_features = int(2 * hidden_features / 3)
        self.fc1 = nn.Linear(in_features, hidden_features * 2)
        self.dwconv = DWConv1D(hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x, v = self.fc1(x).chunk(2, dim=-1)
        x = self.act(self.dwconv(x)) * v
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        temp = self.fn(x, **kwargs) + x
        return  temp

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads=8):
        super().__init__()
        self.heads = heads
        self.scale = dim ** -0.5

        self.to_qkv = nn.Linear(dim, dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(dim, dim),

        )

    def forward(self, x, mask=None):
        b, n, _, h = *x.shape, self.heads
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=h), qkv)
        dots = torch.einsum('bhid,bhjd->bhij', q, k) * self.scale

        if mask is not None:
            mask = F.pad(mask.flatten(1), (1, 0), value=True)
            assert mask.shape[-1] == dots.shape[-1], 'mask has incorrect dimensions'
            mask = mask[:, None, :] * mask[:, :, None]
            dots.masked_fill_(~mask, float('-inf'))
            del mask

        attn = dots.softmax(dim=-1)

        out = torch.einsum('bhij,bhjd->bhid', attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        out = self.to_out(out)
        return out

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(dim, Attention(dim, heads=heads))),
                # Residual(PreNorm(dim, FeedForward(dim, mlp_dim)))
                Residual(PreNorm(dim, ConvolutionalGLU_1d(dim)))
            ]))

    def forward(self, x, mask=None):
        for attn, ff in self.layers:
            x = attn(x, mask=mask)
            x = ff(x)

        return x

class PatchEmbed(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv1d(in_channels=1, out_channels=9, kernel_size=9,stride=9)

    def forward(self, x):
        x = self.conv(x)
        return x


# 实现高效加性注意力模块（Efficient Additive Attention）
class EfficientAdditiveAttnetion(nn.Module):
    """
    Efficient Additive Attention module for SwiftFormer.
    Input: tensor in shape [B, N, D]
    Output: tensor in shape [B, N, D]

    SwiftFormer的高效加性注意力模块。
    输入: 形状为 [B, N, D] 的张量
    输出: 形状为 [B, N, D] 的张量
    """

    def __init__(self, in_dims=128, token_dim=128, num_heads=4):
        super().__init__()
        self.to_query = nn.Linear(in_dims, token_dim * num_heads)  # 查询向量投影
        self.to_key = nn.Linear(in_dims, token_dim * num_heads)    # 键向量投影
        self.w_g = nn.Parameter(torch.randn(token_dim * num_heads, 1))  # 权重矩阵
        self.scale_factor = token_dim ** -0.5  # 缩放因子
        self.Proj = nn.Linear(token_dim * num_heads, token_dim * num_heads)  # 投影
        self.final = nn.Linear(token_dim * num_heads, token_dim)  # 最终的线性变换

    def forward(self, x, mask=None):
        query = self.to_query(x)
        key = self.to_key(x)
        query = torch.nn.functional.normalize(query, dim=-1)  # 标准化查询向量
        key = torch.nn.functional.normalize(key, dim=-1)      # 标准化键向量
        query_weight = query @ self.w_g  # 计算权重
        A = query_weight * self.scale_factor  # 缩放权重
        A = torch.nn.functional.normalize(A, dim=1)  # 标准化
        G = torch.sum(A * query, dim=1)  # 计算全局特征
        G = einops.repeat(G, "b d -> b repeat d", repeat=key.shape[1])  # 广播全局特征
        out = self.Proj(G * key) + query  # 计算输出
        out = self.final(out)  # 最终线性变换
        return out

class EfficientTransformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(dim, EfficientAdditiveAttnetion(in_dims=dim, token_dim=dim, num_heads=heads))),
                # Residual(PreNorm(dim, FeedForward(dim, mlp_dim)))
                Residual(PreNorm(dim, ConvolutionalGLU_1d(dim)))
            ]))

    def forward(self, x, mask=None):
        for attn, ff in self.layers:
            x = x + attn(x, mask=mask)
            x = x + ff(x)
        return x

class ViT(nn.Module):
    def __init__(self, *, patch_size, channel, split_bandlength, dim, depth, heads, mlp_dim, dropout=0.1,
                 emb_dropout=0.1, verbose=True):
        super().__init__()
        num_patches = int(channel / split_bandlength)
        patch_dim = patch_size

        self.patch_size = patch_size

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))

        # self.split_band = nn.Conv1d(in_channels=patch_dim, out_channels=split_bandlength, kernel_size=split_bandlength, stride=split_bandlength)
        # self.patch_to_embedding = nn.Linear(split_bandlength, dim)

        self.patch_to_embedding = nn.Conv1d(in_channels=patch_dim, out_channels=dim, kernel_size=split_bandlength, stride=split_bandlength)

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        # self.transformer = EfficientTransformer(dim, depth, heads, mlp_dim, dropout)
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout)

        self.dropout = nn.Dropout(emb_dropout)
        self.to_cls_token = nn.Identity()

        # if verbose:
        #     print(f'{self._get_name()} - Number of parameters: {self.count_params()}  \n')

    def count_params(self):
        return sum(p.numel() for p in self.parameters())

    def forward(self, img, mask=None):
        img = img.unsqueeze(1)
        # x = self.split_band(img)

        x = self.patch_to_embedding(img)
        x = x.transpose(1, 2)
        b, n, _ = x.shape
        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)
        x = self.transformer(x, mask)
        x = self.to_cls_token(x[:, 0])
        return x


class ViT_V(nn.Module):
    def __init__(self, *, patch_size, channel, split_bandlength, dim, depth, heads, mlp_dim, dropout=0.1,
                 emb_dropout=0.1, verbose=True):
        super().__init__()
        num_patches = int(channel / split_bandlength)
        patch_dim = patch_size

        self.patch_size = patch_size

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))

        # self.split_band = nn.Conv1d(in_channels=patch_dim, out_channels=split_bandlength, kernel_size=split_bandlength, stride=split_bandlength)
        # self.patch_to_embedding = nn.Linear(split_bandlength, dim)

        self.patch_to_embedding = nn.Conv1d(in_channels=patch_dim, out_channels=dim, kernel_size=split_bandlength, stride=split_bandlength)

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        # self.transformer = EfficientTransformer(dim, depth, heads, mlp_dim, dropout)
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout)

        self.dropout = nn.Dropout(emb_dropout)
        self.to_cls_token = nn.Identity()

        # if verbose:
        #     print(f'{self._get_name()} - Number of parameters: {self.count_params()}  \n')

    def count_params(self):
        return sum(p.numel() for p in self.parameters())

    def forward(self, img, mask=None):
        img = img.unsqueeze(1)
        # x = self.split_band(img)

        x = self.patch_to_embedding(img)
        x = x.transpose(1, 2)
        b, n, _ = x.shape
        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)
        x = self.transformer(x, mask)
        x = self.to_cls_token(x[:, 0])
        return x




class SiameseNet(nn.Module):
    def __init__(self, embedding_net):
        super(SiameseNet, self).__init__()
        self.embedding_net = embedding_net

    def forward(self, prior_spectral,x_spectral):
        return self.embedding_net(prior_spectral), self.embedding_net(x_spectral)

    def get_embedding(self, x):
        return self.embedding_net(x)


class TripletNet(nn.Module):
    def __init__(self, embed_net):
        super(TripletNet, self).__init__()
        self.embed_net = embed_net

    def forward(self, a, p, n):
        embedded_a = self.embed_net(a)
        embedded_p = self.embed_net(p)
        embedded_n = self.embed_net(n)
        return embedded_a, embedded_p, embedded_n

    def feature_extract(self, x):
        return self.embed_net(x)
class SpectralEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpectralEncoder, self).__init__()
        self.input_channels = input_channels  # 100
        self.patch_size = patch_size  # 9
        self.feature_dim = feature_dim  # 128
        self.inter_size = 24
        #
        self.conv1 = nn.Conv3d(1, self.inter_size, kernel_size=(7, 1, 1), stride=(2, 1, 1), padding=(1, 0, 0),
                               bias=True)  # stride = 2 -> 1 too slow ; add zero-padding
        self.bn1 = nn.BatchNorm3d(self.inter_size)
        self.activation1 = nn.ReLU()

        self.conv2 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(7, 1, 1), stride=(1, 1, 1), padding=(3, 0, 0), padding_mode='zeros', bias=True)
        self.bn2 = nn.BatchNorm3d(self.inter_size)
        self.activation2 = nn.ReLU()

        self.conv3 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(7, 1, 1), stride=(1, 1, 1), padding=(3, 0, 0), padding_mode='zeros', bias=True)
        self.bn3 = nn.BatchNorm3d(self.inter_size)
        self.activation3 = nn.ReLU()

        self.conv4 = nn.Conv3d(self.inter_size, self.feature_dim,
                               kernel_size=(((self.input_channels - 7 + 2 * 1) // 2 + 1), 1, 1), bias=True)
        self.bn4 = nn.BatchNorm3d(self.feature_dim)
        self.activation4 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 4, 4))

    def forward(self, x,z=False):  # (batchsize, 100, 9, 9)
        x = x.unsqueeze(1)  # (batchsize, 100, 9, 9) -> (batchsize, 1, 100, 9, 9)

        # Convolution layer 1
        x1 = self.conv1(x)  # (batchsize, 16, 94, 9, 9)
        x1 = self.activation1(self.bn1(x1))

        # Residual layer 1
        residual = x1
        x1 = self.conv2(x1)
        x1 = self.activation2(self.bn2(x1))
        x1 = self.conv3(x1)
        x1 = residual + x1
        x1 = self.activation3(self.bn3(x1))

        # Convolution layer to combine rest
        x1 = self.conv4(x1)  # (batchsize, 128, 1, 9, 9)
        x1 = self.activation4(self.bn4(x1))
        x1 = x1.reshape(x1.size(0), x1.size(1), x1.size(3), x1.size(4))  # (batchsize, 128, 9, 9)
        if(z):
            x1 = self.avgpool2(x1)
        else:
            x1 = self.avgpool(x1)  # (batchsize, 128, 1, 1)
        x1 = x1.reshape((x1.size(0), -1))  # (batchsize, 128)
        return x1


class SpatialEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpatialEncoder, self).__init__()
        self.input_channels = input_channels  # 100
        self.patch_size = patch_size  # 9
        self.feature_dim = feature_dim  # 128
        self.inter_size = 24

        # Convolution layer for spatial information
        self.conv5 = nn.Conv3d(1, self.inter_size, kernel_size=(self.input_channels, 1, 1))
        self.bn5 = nn.BatchNorm3d(self.inter_size)
        self.activation5 = nn.ReLU()

        # Residual block 2
        self.conv8 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 1, 1))

        self.conv6 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1), padding_mode='zeros', bias=True)
        self.bn6 = nn.BatchNorm3d(self.inter_size)
        self.activation6 = nn.ReLU()
        self.conv7 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1), padding_mode='zeros', bias=True)
        self.bn7 = nn.BatchNorm3d(self.inter_size)
        self.activation7 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 4, 4))
        #self.kan = KAN([self.inter_size,64,self.feature_dim])
        self.fc = nn.Sequential(nn.Dropout(p=0.5),
                                nn.Linear(self.inter_size, out_features=self.feature_dim))

    def forward(self, x,z=False):  # (batchsize, 100, 9, 9)
        x = x.unsqueeze(1)  # (batchsize, 100, 9, 9) -> (batchsize, 1, 100, 9, 9)

        x2 = self.conv5(x)  # (batchsize, 16, 1, 9, 9)
        x2 = self.activation5(self.bn5(x2))

        # Residual layer 2
        residual = x2
        residual = self.conv8(residual)  # (batchsize, 16, 1, 9, 9) why? this is not residual !
        x2 = self.conv6(x2)
        x2 = self.activation6(self.bn6(x2))
        x_wenli =x2
        x2 = self.conv7(x2)
        x2 = residual + x2  # (batchsize, 16, 1, 9, 9)

        x2 = self.activation7(self.bn7(x2))
        x2 = x2.reshape(x2.size(0), x2.size(1), x2.size(3), x2.size(4))  # (batchsize, 16, 9, 9)
        if(z):
            x2 = self.avgpool2(x2)
        else:
            x2 = self.avgpool(x2)
        #x2 = self.avgpool(x2)  # (batchsize, 16, 1, 1)
        x2 = x2.reshape((x2.size(0), -1))  # (batchsize, 16)

        x2 = self.fc(x2)  # (batchsize, 128)
        #x2 = self.kan(x2)
        return x2
class WordEmbTransformers(nn.Module):
    def __init__(self, feature_dim):
        super(WordEmbTransformers, self).__init__()
        self.feature_dim = feature_dim
        # not add BN
        self.fc = nn.Sequential(nn.Linear(in_features=768,
                                           out_features=128,
                                           bias=True),
                                # nn.BatchNorm1d(128),
                                nn.ReLU(),
                                nn.Dropout(p=0.5), # too important, without it, OA down to 65
                                nn.Linear(in_features=128,
                                          out_features=self.feature_dim,
                                          bias=True)
                                # nn.BatchNorm1d(self.feature_dim),
                                )

    def forward(self, x):
        # 0-1
        x = self.fc(x)
        return x


class AttentionWeight(nn.Module):
    def __init__(self, feature_dim, hidden_layer, dropout):
        super(AttentionWeight, self).__init__()
        self.feature_dim = feature_dim
        self.hidden_layer = hidden_layer
        self.dropout = dropout

        self.getAttentionWeight = nn.Sequential(nn.Linear(in_features=self.feature_dim,
                                                          out_features=self.hidden_layer),
                                                nn.ReLU(),
                                                nn.Dropout(p=self.dropout), # 0.3
                                                nn.Linear(in_features=self.hidden_layer,
                                                          out_features=1),
                                                nn.Sigmoid()
                                                )

    def forward(self,x): # (batchsize, 128)
        x = self.getAttentionWeight(x) # (batchsize, 1)
        return x


class Encoder(nn.Module):
    def __init__(self, n_dimension, patch_size, emb_size):
        super(Encoder, self).__init__()
        self.n_dimension = n_dimension
        self.patch_size = patch_size
        self.emb_size = emb_size
        self.embednet = ViT(dim=512, patch_size=1, channel=1024, split_bandlength=64,
                             depth=2, heads=4, mlp_dim=8, dropout=0.1, emb_dropout=0.1, )
        self.vit=self.embednet
        self.spectral_encoder = SpectralEncoder(input_channels=self.n_dimension, patch_size=self.patch_size, feature_dim=512)
        self.spatial_encoder = SpatialEncoder(input_channels=self.n_dimension, patch_size=self.patch_size, feature_dim=512)
        self.word_emb_transformers = WordEmbTransformers(feature_dim=self.emb_size)

    def forward(self, x, semantic_feature = "", s_or_q = "query",z=False): # UP (9, 100, 9, 9)
        spatial_feature = self.spatial_encoder(x,z) # (9, 128)
        spectral_feature =  self.spectral_encoder(x,z)  # (9, 128)
        spatial_spectral_fusion_feature = 0.5*spatial_feature + 0.5*spectral_feature # (9, 128)
        return spatial_spectral_fusion_feature
class Encoder2(nn.Module):
    def __init__(self):
        super(Encoder2, self).__init__()

        self.getAttentionWeight = nn.Sequential(nn.Linear(in_features=128,
                                                          out_features=2048),

                                                nn.ReLU(),
                                                nn.Dropout(p=0.3),  # 0.3
                                                nn.Linear(2048,
                                                          out_features=18),
                                                )

    def forward(self, x):  # UP (9, 100, 9, 9)
        out = self.getAttentionWeight(x)
        return out

class Deconder(nn.Module):
    def __init__(self):
        super(Deconder, self).__init__()

        self.getAttentionWeight = nn.Sequential(nn.Linear(18,
                                                          out_features=2048),

                                                nn.ReLU(),
                                                nn.Dropout(p=0.3),  # 0.3
                                                nn.Linear(2048,
                                                          out_features=128),



        )

    def forward(self, x):  # UP (9, 100, 9, 9)
        out = self.getAttentionWeight(x)
        return out




