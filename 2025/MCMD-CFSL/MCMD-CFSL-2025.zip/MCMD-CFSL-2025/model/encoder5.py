import torch
import torch.nn as nn
import torch.nn.functional as F


class SpectralEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpectralEncoder, self).__init__()
        self.input_channels = input_channels  # 100
        self.patch_size = patch_size  # 9
        self.feature_dim = feature_dim  # 128
        self.inter_size = 24
        #
        self.conv1 = nn.Conv3d(1, self.inter_size, kernel_size=(7, 1, 1), stride=(2, 1, 1), padding=(1, 0, 0),
                               bias=True)  # stride = 2 -> 1 too slow ; add zero-padding
        self.bn1 = nn.BatchNorm3d(self.inter_size)
        self.activation1 = nn.ReLU()

        self.conv2 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(7, 1, 1), stride=(1, 1, 1),
                               padding=(3, 0, 0), padding_mode='zeros', bias=True)
        self.bn2 = nn.BatchNorm3d(self.inter_size)
        self.activation2 = nn.ReLU()

        self.conv3 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(7, 1, 1), stride=(1, 1, 1),
                               padding=(3, 0, 0), padding_mode='zeros', bias=True)
        self.bn3 = nn.BatchNorm3d(self.inter_size)
        self.activation3 = nn.ReLU()

        self.conv4 = nn.Conv3d(self.inter_size, self.feature_dim,
                               kernel_size=(((self.input_channels - 7 + 2 * 1) // 2 + 1), 1, 1), bias=True)
        self.bn4 = nn.BatchNorm3d(self.feature_dim)
        self.activation4 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 5, 5))

    def forward(self, x, z=False):  # (batchsize, 100, 9, 9)
        x = x.unsqueeze(1)  # (batchsize, 100, 9, 9) -> (batchsize, 1, 100, 9, 9)

        # Convolution layer 1
        x1 = self.conv1(x)  # (batchsize, 16, 94, 9, 9)
        x1 = self.activation1(self.bn1(x1))

        # Residual layer 1
        residual = x1
        x1 = self.conv2(x1)
        x1 = self.activation2(self.bn2(x1))
        x1 = self.conv3(x1)
        x1 = residual + x1
        x1 = self.activation3(self.bn3(x1))

        # Convolution layer to combine rest
        x1 = self.conv4(x1)  # (batchsize, 128, 1, 9, 9)
        x1 = self.activation4(self.bn4(x1))
        x1 = x1.reshape(x1.size(0), x1.size(1), x1.size(3), x1.size(4))  # (batchsize, 128, 9, 9)
        if (z):
            x1 = self.avgpool2(x1)
        else:
            x1 = self.avgpool(x1)  # (batchsize, 128, 1, 1)
        x1 = x1.reshape((x1.size(0), -1))  # (batchsize, 128)
        return x1


class SpatialEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpatialEncoder, self).__init__()
        self.input_channels = input_channels  # 100
        self.patch_size = patch_size  # 9
        self.feature_dim = feature_dim  # 128
        self.inter_size = 24

        # Convolution layer for spatial information
        self.conv5 = nn.Conv3d(1, self.inter_size, kernel_size=(self.input_channels, 1, 1))
        self.bn5 = nn.BatchNorm3d(self.inter_size)
        self.activation5 = nn.ReLU()

        # Residual block 2
        self.conv8 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 1, 1))

        self.conv6 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                               padding=(0, 1, 1), padding_mode='zeros', bias=True)
        self.bn6 = nn.BatchNorm3d(self.inter_size)
        self.activation6 = nn.ReLU()
        self.conv7 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                               padding=(0, 1, 1), padding_mode='zeros', bias=True)
        self.bn7 = nn.BatchNorm3d(self.inter_size)
        self.activation7 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 5, 5))
        # self.kan = KAN([self.inter_size,64,self.feature_dim])
        self.fc = nn.Sequential(nn.Dropout(p=0.5),
                                nn.Linear(self.inter_size, out_features=self.feature_dim))

    def forward(self, x, z=False):  # (batchsize, 100, 9, 9)
        x = x.unsqueeze(1)  # (batchsize, 100, 9, 9) -> (batchsize, 1, 100, 9, 9)

        x2 = self.conv5(x)  # (batchsize, 16, 1, 9, 9)
        x2 = self.activation5(self.bn5(x2))

        # Residual layer 2
        residual = x2
        residual = self.conv8(residual)  # (batchsize, 16, 1, 9, 9) why? this is not residual !
        x2 = self.conv6(x2)
        x2 = self.activation6(self.bn6(x2))
        x_wenli = x2
        x2 = self.conv7(x2)

        x2 = residual + x2  # (batchsize, 16, 1, 9, 9)

        x2 = self.activation7(self.bn7(x2))
        x2 = x2.reshape(x2.size(0), x2.size(1), x2.size(3), x2.size(4))  # (batchsize, 16, 9, 9)
        if (z):
            x2 = self.avgpool2(x2)
        else:
            x2 = self.avgpool(x2)
        # x2 = self.avgpool(x2)  # (batchsize, 16, 1, 1)
        x2 = x2.reshape((x2.size(0), -1))  # (batchsize, 16)

        x2 = self.fc(x2)  # (batchsize, 128)
        # x2 = self.kan(x2)
        return x2,x_wenli


class WordEmbTransformers(nn.Module):
    def __init__(self, feature_dim):
        super(WordEmbTransformers, self).__init__()
        self.feature_dim = feature_dim
        # not add BN
        self.fc = nn.Sequential(nn.Linear(in_features=768,
                                          out_features=128,
                                          bias=True),
                                # nn.BatchNorm1d(128),
                                nn.ReLU(),
                                nn.Dropout(p=0.5),  # too important, without it, OA down to 65
                                nn.Linear(in_features=128,
                                          out_features=self.feature_dim,
                                          bias=True)
                                # nn.BatchNorm1d(self.feature_dim),
                                )

    def forward(self, x):
        # 0-1
        x = self.fc(x)
        return x


class Encoder(nn.Module):
    def __init__(self, n_dimension, patch_size, emb_size):
        super(Encoder, self).__init__()
        self.n_dimension = n_dimension
        self.patch_size = patch_size
        self.emb_size = emb_size

        self.spectral_encoder = SpectralEncoder(input_channels=self.n_dimension, patch_size=self.patch_size,
                                                feature_dim=768)
        self.spatial_encoder = SpatialEncoder(input_channels=self.n_dimension, patch_size=self.patch_size,
                                              feature_dim=768)
        self.word_emb_transformers = WordEmbTransformers(feature_dim=self.emb_size)

    def forward(self, x, semantic_feature="", semantic_feature2="", s_or_q="query", z=False,f=False,weights=None):  # UP (9, 100, 9, 9)
        spatial_feature,x_wenli = self.spatial_encoder(x, z)  # (9, 128)
        spectral_feature = self.spectral_encoder(x, z)  # (9, 128)
        if weights is None:
            spatial_spectral_fusion_feature = 0.5 * spatial_feature + 0.5 * spectral_feature  # (9, 128)
        else:
            if weights.size(0)==2:
             spatial_spectral_fusion_feature = weights[0]*spatial_feature+weights[1]*spectral_feature
            else:
             num=spatial_feature.size(0)
             spatial_spectral_fusion_feature = torch.zeros_like(spatial_feature)  # (9, 128)
             for i in range(num):
                spatial_spectral_fusion_feature[i] = weights[i, 0] * spatial_feature[i] + weights[i, 1] * spectral_feature[i]


        if s_or_q == "support":  # semantic_feature = (9, 768)
            semantic_feature = semantic_feature  # (9, 128)
            semantic_feature2 = semantic_feature2
            return spatial_spectral_fusion_feature, spatial_feature, spectral_feature, semantic_feature, semantic_feature2
        if f:
            return spatial_spectral_fusion_feature, spatial_feature, spectral_feature
        return spatial_spectral_fusion_feature




