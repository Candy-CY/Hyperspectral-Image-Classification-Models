import einops
import torch
import torch.nn.functional as F
from torch import nn
from einops import rearrange, repeat

# ----------------------- vit -----------------------
# class Conv1d(nn.Module):
#     def __init__(self, dim=768):
#         super(Conv1d, self).__init__()
#         # 定义一个一维深度卷积层，输入和输出通道数相同，卷积核大小为3，步幅为1，填充为1，组数为输入通道数
#         self.dwconv = nn.Conv1d(dim, dim, kernel_size=3, stride=1, padding=1, bias=True, groups=dim)
#
#     def forward(self, x):
#         # 调整形状为 (B, C, N)     (batch_size, sequence_length, num_channels)
#         x = x.transpose(1, 2).contiguous()
#         x = self.dwconv(x)  # 进行深度卷积操作
#         # 调整形状为 (B, N, C)
#         x = x.transpose(1, 2).contiguous()
#         return x
#
#
# class ConvolutionalGLU_1d(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         hidden_features = int(2 * hidden_features / 3)
#         self.fc1 = nn.Linear(in_features, hidden_features * 2)
#         self.conv = Conv1d(hidden_features)
#         self.act = nn.GELU()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)
#
#     def forward(self, x):
#         x =  self.fc1(x)
#         x, v = x.chunk(2, dim=-1)
#         x = self.act(self.conv(x)) * v
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x

class DWConv1D(nn.Module):
    def __init__(self, dim=768):
        super(DWConv1D, self).__init__()
        # 定义一个一维深度卷积层，输入和输出通道数相同，卷积核大小为3，步幅为1，填充为1，组数为输入通道数
        self.dwconv = nn.Conv1d(dim, dim, kernel_size=3, stride=1, padding=1, bias=True, groups=dim)

    def forward(self, x):
        # 调整形状为 (B, C, N)     (batch_size, sequence_length, num_channels)
        x = x.transpose(1, 2).contiguous()
        x = self.dwconv(x)  # 进行深度卷积操作
        # 调整形状为 (B, N, C)
        x = x.transpose(1, 2).contiguous()
        return x


class ConvolutionalGLU_1d(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        hidden_features = int(2 * hidden_features / 3)
        self.fc1 = nn.Linear(in_features, hidden_features * 2)
        self.dwconv = DWConv1D(hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x, v = self.fc1(x).chunk(2, dim=-1)
        x = self.act(self.dwconv(x)) * v
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        temp = self.fn(x, **kwargs) + x
        return  temp

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads=8):
        super().__init__()
        self.heads = heads
        self.scale = dim ** -0.5

        self.to_qkv = nn.Linear(dim, dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(dim, dim),

        )

    def forward(self, x, mask=None):
        b, n, _, h = *x.shape, self.heads
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=h), qkv)
        dots = torch.einsum('bhid,bhjd->bhij', q, k) * self.scale

        if mask is not None:
            mask = F.pad(mask.flatten(1), (1, 0), value=True)
            assert mask.shape[-1] == dots.shape[-1], 'mask has incorrect dimensions'
            mask = mask[:, None, :] * mask[:, :, None]
            dots.masked_fill_(~mask, float('-inf'))
            del mask

        attn = dots.softmax(dim=-1)

        out = torch.einsum('bhij,bhjd->bhid', attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        out = self.to_out(out)
        return out

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(dim, Attention(dim, heads=heads))),
                # Residual(PreNorm(dim, FeedForward(dim, mlp_dim)))
                Residual(PreNorm(dim, ConvolutionalGLU_1d(dim)))
            ]))

    def forward(self, x, mask=None):
        for attn, ff in self.layers:
            x = attn(x, mask=mask)
            x = ff(x)

        return x

class PatchEmbed(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Conv1d(in_channels=1, out_channels=9, kernel_size=9,stride=9)

    def forward(self, x):
        x = self.conv(x)
        return x


# 实现高效加性注意力模块（Efficient Additive Attention）
class EfficientAdditiveAttnetion(nn.Module):
    """
    Efficient Additive Attention module for SwiftFormer.
    Input: tensor in shape [B, N, D]
    Output: tensor in shape [B, N, D]

    SwiftFormer的高效加性注意力模块。
    输入: 形状为 [B, N, D] 的张量
    输出: 形状为 [B, N, D] 的张量
    """

    def __init__(self, in_dims=128, token_dim=128, num_heads=4):
        super().__init__()
        self.to_query = nn.Linear(in_dims, token_dim * num_heads)  # 查询向量投影
        self.to_key = nn.Linear(in_dims, token_dim * num_heads)    # 键向量投影
        self.w_g = nn.Parameter(torch.randn(token_dim * num_heads, 1))  # 权重矩阵
        self.scale_factor = token_dim ** -0.5  # 缩放因子
        self.Proj = nn.Linear(token_dim * num_heads, token_dim * num_heads)  # 投影
        self.final = nn.Linear(token_dim * num_heads, token_dim)  # 最终的线性变换

    def forward(self, x, mask=None):
        query = self.to_query(x)
        key = self.to_key(x)
        query = torch.nn.functional.normalize(query, dim=-1)  # 标准化查询向量
        key = torch.nn.functional.normalize(key, dim=-1)      # 标准化键向量
        query_weight = query @ self.w_g  # 计算权重
        A = query_weight * self.scale_factor  # 缩放权重
        A = torch.nn.functional.normalize(A, dim=1)  # 标准化
        G = torch.sum(A * query, dim=1)  # 计算全局特征
        G = einops.repeat(G, "b d -> b repeat d", repeat=key.shape[1])  # 广播全局特征
        out = self.Proj(G * key) + query  # 计算输出
        out = self.final(out)  # 最终线性变换
        return out

class EfficientTransformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(dim, EfficientAdditiveAttnetion(in_dims=dim, token_dim=dim, num_heads=heads))),
                # Residual(PreNorm(dim, FeedForward(dim, mlp_dim)))
                Residual(PreNorm(dim, ConvolutionalGLU_1d(dim)))
            ]))

    def forward(self, x, mask=None):
        for attn, ff in self.layers:
            x = x + attn(x, mask=mask)
            x = x + ff(x)
        return x

class ViT(nn.Module):
    def __init__(self, *, patch_size, channel, split_bandlength, dim, depth, heads, mlp_dim, dropout=0.1,
                 emb_dropout=0.1, verbose=True):
        super().__init__()
        num_patches = int(channel / split_bandlength)
        patch_dim = patch_size

        self.patch_size = patch_size

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))

        # self.split_band = nn.Conv1d(in_channels=patch_dim, out_channels=split_bandlength, kernel_size=split_bandlength, stride=split_bandlength)
        # self.patch_to_embedding = nn.Linear(split_bandlength, dim)

        self.patch_to_embedding = nn.Conv1d(in_channels=patch_dim, out_channels=dim, kernel_size=split_bandlength, stride=split_bandlength)

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        # self.transformer = EfficientTransformer(dim, depth, heads, mlp_dim, dropout)
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout)

        self.dropout = nn.Dropout(emb_dropout)
        self.to_cls_token = nn.Identity()

        # if verbose:
        #     print(f'{self._get_name()} - Number of parameters: {self.count_params()}  \n')

    def count_params(self):
        return sum(p.numel() for p in self.parameters())

    def forward(self, img, mask=None):
        img = img.unsqueeze(1)
        # x = self.split_band(img)

        x = self.patch_to_embedding(img)
        x = x.transpose(1, 2)
        b, n, _ = x.shape
        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)
        x = self.transformer(x, mask)
        x = self.to_cls_token(x[:, 0])
        return x


class ViT_V(nn.Module):
    def __init__(self, *, patch_size, channel, split_bandlength, dim, depth, heads, mlp_dim, dropout=0.1,
                 emb_dropout=0.1, verbose=True):
        super().__init__()
        num_patches = int(channel / split_bandlength)
        patch_dim = patch_size

        self.patch_size = patch_size

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))

        # self.split_band = nn.Conv1d(in_channels=patch_dim, out_channels=split_bandlength, kernel_size=split_bandlength, stride=split_bandlength)
        # self.patch_to_embedding = nn.Linear(split_bandlength, dim)

        self.patch_to_embedding = nn.Conv1d(in_channels=patch_dim, out_channels=dim, kernel_size=split_bandlength, stride=split_bandlength)

        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        # self.transformer = EfficientTransformer(dim, depth, heads, mlp_dim, dropout)
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout)

        self.dropout = nn.Dropout(emb_dropout)
        self.to_cls_token = nn.Identity()

        # if verbose:
        #     print(f'{self._get_name()} - Number of parameters: {self.count_params()}  \n')

    def count_params(self):
        return sum(p.numel() for p in self.parameters())

    def forward(self, img, mask=None):
        img = img.unsqueeze(1)
        # x = self.split_band(img)

        x = self.patch_to_embedding(img)
        x = x.transpose(1, 2)
        b, n, _ = x.shape
        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b=b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)
        x = self.transformer(x, mask)
        x = self.to_cls_token(x[:, 0])
        return x




class SiameseNet(nn.Module):
    def __init__(self, embedding_net):
        super(SiameseNet, self).__init__()
        self.embedding_net = embedding_net

    def forward(self, prior_spectral,x_spectral):
        return self.embedding_net(prior_spectral), self.embedding_net(x_spectral)

    def get_embedding(self, x):
        return self.embedding_net(x)


class TripletNet(nn.Module):
    def __init__(self, embed_net):
        super(TripletNet, self).__init__()
        self.embed_net = embed_net

    def forward(self, a, p, n):
        embedded_a = self.embed_net(a)
        embedded_p = self.embed_net(p)
        embedded_n = self.embed_net(n)
        return embedded_a, embedded_p, embedded_n

    def feature_extract(self, x):
        return self.embed_net(x)


if __name__ == '__main__':
    embedded_net = ViT(
        dim=128,
        patch_size=1,
        channel = 100,
        split_bandlength = 10,
        depth=2,  # 12
        heads=4,
        mlp_dim=8,
        dropout=0.1,
        emb_dropout=0.1,

    )
    net = TripletNet(embedded_net)


    tensor_1 = torch.randn(35,100)
    tensor_2 = torch.randn(35, 100)
    tensor_3 = torch.randn(35, 100)
    output1,output2,output3, = net(tensor_1,tensor_2,tensor_3)
    print(output1.shape)

